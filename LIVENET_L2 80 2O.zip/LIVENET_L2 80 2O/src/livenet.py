import os
os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
from torchvision import transforms
from torchvision.models import vgg16
from PIL import Image
from tqdm import tqdm
from skimage.metrics import peak_signal_noise_ratio as psnr
import lpips  # Perceptual similarity (LPIPS)


# Dataset class for LOLv1 without resizing images
class LOLv1Dataset(Dataset):
    def __init__(self, noisy_dir, clean_dir, transform=None):
        valid_extensions = ('.jpg', '.jpeg', '.png', '.bmp')
        self.noisy_images = [f for f in sorted(os.listdir(noisy_dir)) if f.lower().endswith(valid_extensions)]
        self.clean_images = [f for f in sorted(os.listdir(clean_dir)) if f.lower().endswith(valid_extensions)]
        self.noisy_dir = noisy_dir
        self.clean_dir = clean_dir
        self.transform = transform

    def __len__(self):
        return len(self.noisy_images)

    def __getitem__(self, index):
        noisy_path = os.path.join(self.noisy_dir, self.noisy_images[index])
        clean_path = os.path.join(self.clean_dir, self.clean_images[index])

        noisy_image = Image.open(noisy_path).convert('RGB')
        clean_image = Image.open(clean_path).convert('RGB')

        if self.transform:
            noisy_image = self.transform(noisy_image)
            clean_image = self.transform(clean_image)

        return noisy_image, clean_image


# Define LiveNet model with enhanced complexity
class Livenet(nn.Module):
    def __init__(self):
        super(Livenet, self).__init__()
        self.conv1 = nn.Conv2d(3, 64, kernel_size=3, padding=1)
        self.relu = nn.ReLU(inplace=True)
        self.attention = ChannelAttention(64)  # Channel Attention Layer
        self.residual_blocks = nn.Sequential(
            *[ResidualBlock(64) for _ in range(10)]  # Increased to 10 residual blocks
        )
        self.conv2 = nn.Conv2d(64, 3, kernel_size=3, padding=1)

    def forward(self, x):
        x = self.relu(self.conv1(x))
        x = self.attention(x)
        x = self.residual_blocks(x)
        x = self.conv2(x)
        return x


class ResidualBlock(nn.Module):
    def __init__(self, channels):
        super(ResidualBlock, self).__init__()
        self.block = nn.Sequential(
            nn.Conv2d(channels, channels, kernel_size=3, padding=1),
            nn.ReLU(inplace=True),
            nn.Conv2d(channels, channels, kernel_size=3, padding=1)
        )

    def forward(self, x):
        return x + self.block(x)  # Skip connection


# Channel Attention mechanism for focusing on important features
class ChannelAttention(nn.Module):
    def __init__(self, in_planes, ratio=16):
        super(ChannelAttention, self).__init__()
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.max_pool = nn.AdaptiveMaxPool2d(1)

        self.fc1 = nn.Conv2d(in_planes, in_planes // ratio, 1, bias=False)
        self.relu1 = nn.ReLU(inplace=True)
        self.fc2 = nn.Conv2d(in_planes // ratio, in_planes, 1, bias=False)

        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        avg_out = self.fc2(self.relu1(self.fc1(self.avg_pool(x))))
        max_out = self.fc2(self.relu1(self.fc1(self.max_pool(x))))
        out = avg_out + max_out
        return self.sigmoid(out) * x


# Perceptual loss using a pre-trained VGG network
class PerceptualLoss(nn.Module):
    def __init__(self):
        super(PerceptualLoss, self).__init__()
        vgg = vgg16(pretrained=True).features[:16].eval()  # Use up to the 3rd conv layer
        for param in vgg.parameters():
            param.requires_grad = False
        self.vgg = vgg

    def forward(self, x, y):
        x_vgg = self.vgg(x)
        y_vgg = self.vgg(y)
        return nn.functional.mse_loss(x_vgg, y_vgg)


# Training function with weighted L2 and VGG loss
def train_model(model, train_loader, criterion, optimizer, device, perceptual_loss=None):
    model.train()
    running_loss = 0.0
    for i, (noisy, clean) in enumerate(tqdm(train_loader, desc="Training")):
        noisy, clean = noisy.to(device), clean.to(device)

        # Forward pass
        outputs = model(noisy)

        # L2 Loss (MSE)
        l2_loss = criterion(outputs, clean)

        # Perceptual loss
        p_loss = perceptual_loss(outputs, clean) if perceptual_loss else 0

        # Weighted total loss
        total_loss = 0.8 * l2_loss + 0.2 * p_loss

        # Backward pass and optimization
        optimizer.zero_grad()
        total_loss.backward()
        optimizer.step()

        running_loss += total_loss.item()

    return running_loss / len(train_loader)


# Evaluation function with PSNR, LPIPS, and MAE metrics
def evaluate_model(model, eval_loader, device, output_dir):
    model.eval()
    os.makedirs(output_dir, exist_ok=True)
    lpips_fn = lpips.LPIPS(net='alex')  # Initialize LPIPS with AlexNet
    lpips_fn = lpips_fn.to(device)
    psnr_values = []
    lpips_values = []
    mae_values = []

    with torch.no_grad():
        for i, (noisy, clean) in enumerate(tqdm(eval_loader, desc="Evaluating")):
            noisy, clean = noisy.to(device), clean.to(device)

            # Forward pass
            outputs = model(noisy)

            # Convert to CPU for metric calculations
            outputs_cpu = outputs.clamp(0, 1).cpu()
            clean_cpu = clean.clamp(0, 1).cpu()

            # If batch size > 1, loop through each image in the batch for PSNR calculation
            for j in range(outputs_cpu.size(0)):
                output_image = outputs_cpu[j].numpy().transpose(1, 2, 0)
                clean_image = clean_cpu[j].numpy().transpose(1, 2, 0)

                # Calculate PSNR for each image in the batch
                psnr_value = psnr(clean_image, output_image, data_range=1)
                psnr_values.append(psnr_value)

                # Calculate LPIPS for each image in the batch
                lpips_value = lpips_fn(outputs[j].unsqueeze(0), clean[j].unsqueeze(0)).item()
                lpips_values.append(lpips_value)

                # Calculate MAE for each image in the batch
                mae_value = torch.mean(torch.abs(outputs_cpu[j] - clean_cpu[j])).item()
                mae_values.append(mae_value)

                # Save output images
                output_pil = transforms.ToPILImage()(outputs_cpu[j])
                output_pil.save(os.path.join(output_dir, f'output_{i}_{j}.png'))

    avg_psnr = sum(psnr_values) / len(psnr_values)
    avg_lpips = sum(lpips_values) / len(lpips_values)
    avg_mae = sum(mae_values) / len(mae_values)

    print(f"Average PSNR: {avg_psnr:.4f}, Average LPIPS: {avg_lpips:.4f}, Average MAE: {avg_mae:.4f}")


# Main function
def main():
    # Define paths
    TRAIN_NOISY_DIR = r'C:\Users\win11\Desktop\LIVENET_L2 80 20\dataset\train\low'
    TRAIN_CLEAN_DIR = r'C:\Users\win11\Desktop\LIVENET_L2 80 20\dataset\train\normal'
    EVAL_NOISY_DIR = r'C:\Users\win11\Desktop\LIVENET_L2 80 20\dataset\eval\low'
    EVAL_CLEAN_DIR = r'C:\Users\win11\Desktop\LIVENET_L2 80 20\dataset\eval\normal'
    OUTPUT_DIR = r'C:\Users\win11\Desktop\LIVENET_L2 80 20\output_images'

    # Transformations (including basic augmentation)
    transform = transforms.Compose([
        transforms.ToTensor(),
    ])

    # Datasets and DataLoaders
    train_dataset = LOLv1Dataset(TRAIN_NOISY_DIR, TRAIN_CLEAN_DIR, transform=transform)
    eval_dataset = LOLv1Dataset(EVAL_NOISY_DIR, EVAL_CLEAN_DIR, transform=transform)

    train_loader = DataLoader(train_dataset, batch_size=2, shuffle=True)
    eval_loader = DataLoader(eval_dataset, batch_size=2, shuffle=False)

    # Initialize model, loss function, and optimizer
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    model = Livenet().to(device)
    criterion = nn.MSELoss()
    perceptual_loss = PerceptualLoss().to(device)
    optimizer = optim.Adam(model.parameters(), lr=0.0001, weight_decay=1e-5)
    scheduler = optim.lr_scheduler.ReduceLROnPlateau(optimizer, mode='min', factor=0.5, patience=3, verbose=True)

    # Training loop
    num_epochs = 200
    for epoch in range(num_epochs):
        train_loss = train_model(model, train_loader, criterion, optimizer, device, perceptual_loss)
        print(f"Epoch [{epoch + 1}/{num_epochs}], Training Loss: {train_loss:.4f}")

        # Step the scheduler
        scheduler.step(train_loss)

        # After training, evaluate the model
    print("Training complete. Starting evaluation...")
    evaluate_model(model, eval_loader, device, OUTPUT_DIR)


if __name__ == "__main__":
    main()
