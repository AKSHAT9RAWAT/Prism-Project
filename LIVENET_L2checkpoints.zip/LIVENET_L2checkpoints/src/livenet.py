import os
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
from torchvision import transforms
from torchvision.models import vgg19
from tqdm import tqdm
from PIL import Image
from skimage.metrics import peak_signal_noise_ratio as psnr
import lpips
import torch.utils.checkpoint as checkpoint
from torch.cuda.amp import GradScaler, autocast

# Define dataset
class LOLv1Dataset(Dataset):
    def __init__(self, noisy_dir, clean_dir, transform=None):
        valid_extensions = ('.jpg', '.jpeg', '.png', '.bmp')
        self.noisy_images = [f for f in sorted(os.listdir(noisy_dir)) if f.lower().endswith(valid_extensions)]
        self.clean_images = [f for f in sorted(os.listdir(clean_dir)) if f.lower().endswith(valid_extensions)]
        self.noisy_dir = noisy_dir
        self.clean_dir = clean_dir
        self.transform = transform

    def __len__(self):
        return len(self.noisy_images)

    def __getitem__(self, index):
        noisy_path = os.path.join(self.noisy_dir, self.noisy_images[index])
        clean_path = os.path.join(self.clean_dir, self.clean_images[index])
        noisy_image = Image.open(noisy_path).convert('RGB')
        clean_image = Image.open(clean_path).convert('RGB')
        
        if self.transform:
            noisy_image = self.transform(noisy_image)
            clean_image = self.transform(clean_image)

        return noisy_image, clean_image


# Model Definition
class Livenet(nn.Module):
    def __init__(self):
        super(Livenet, self).__init__()
        self.conv1 = nn.Conv2d(3, 64, kernel_size=3, padding=1)
        self.relu = nn.ReLU(inplace=True)
        self.residual_blocks = nn.Sequential(*[ResidualBlock(64) for _ in range(10)])
        self.conv2 = nn.Conv2d(64, 3, kernel_size=3, padding=1)

    def forward(self, x):
        x = self.relu(self.conv1(x))
        x = checkpoint.checkpoint_sequential(self.residual_blocks, 2, x)  # Gradient checkpointing
        x = self.conv2(x)
        return x


class ResidualBlock(nn.Module):
    def __init__(self, channels):
        super(ResidualBlock, self).__init__()
        self.block = nn.Sequential(
            nn.Conv2d(channels, channels, kernel_size=3, padding=1),
            nn.ReLU(inplace=True),
            nn.Conv2d(channels, channels, kernel_size=3, padding=1)
        )

    def forward(self, x):
        return x + self.block(x)  # Skip connection


# Perceptual Loss using VGG19
class PerceptualLoss(nn.Module):
    def __init__(self):
        super(PerceptualLoss, self).__init__()
        vgg = vgg19(pretrained=True).features[:16].eval()
        for param in vgg.parameters():
            param.requires_grad = False
        self.vgg = vgg

    def forward(self, x, y):
        x_vgg = self.vgg(x)
        y_vgg = self.vgg(y)
        return nn.functional.mse_loss(x_vgg, y_vgg)


# Train model function
def train_model(model, train_loader, criterion, optimizer, device, perceptual_loss, scaler):
    model.train()
    running_loss = 0.0
    for noisy, clean in tqdm(train_loader, desc="Training"):
        noisy, clean = noisy.to(device), clean.to(device)

        # Forward pass with mixed precision
        with autocast():
            outputs = model(noisy)
            loss = criterion(outputs, clean)  # L2 loss
            if perceptual_loss:
                p_loss = perceptual_loss(outputs, clean)
                loss += 0.001 * p_loss

        # Backpropagation with gradient scaling
        optimizer.zero_grad()
        scaler.scale(loss).backward()
        scaler.step(optimizer)
        scaler.update()

        running_loss += loss.item()

    return running_loss / len(train_loader)


# Save model checkpoint
def save_checkpoint(model, optimizer, epoch, checkpoint_path):
    torch.save({
        'epoch': epoch,
        'model_state_dict': model.state_dict(),
        'optimizer_state_dict': optimizer.state_dict()
    }, checkpoint_path)


# Main entry point
def main():
    # Paths
    TRAIN_NOISY_DIR = r'C:\Users\win11\Desktop\LIVENET_L2check\dataset\train\low' 
    TRAIN_CLEAN_DIR = r'C:\Users\win11\Desktop\LIVENET_L2check\dataset\train\normal'
    EVAL_NOISY_DIR = r'C:\Users\win11\Desktop\LIVENET_L2check\dataset\eval\low'
    EVAL_CLEAN_DIR = r'C:\Users\win11\Desktop\LIVENET_L2check\dataset\eval\normal'
    CHECKPOINT_PATH = r'C:\Users\win11\Desktop\LIVENET_L2check\model_checkpoint.pth'
    
    # Transformations
    transform = transforms.Compose([
        transforms.Resize((256, 256)),  # Resize images to save memory
        transforms.ToTensor()
    ])

    # Load data
    train_dataset = LOLv1Dataset(TRAIN_NOISY_DIR, TRAIN_CLEAN_DIR, transform)
    train_loader = DataLoader(train_dataset, batch_size=4, shuffle=True)  # Reduced batch size

    eval_dataset = LOLv1Dataset(EVAL_NOISY_DIR, EVAL_CLEAN_DIR, transform)
    eval_loader = DataLoader(eval_dataset, batch_size=4, shuffle=False)

    # Initialize the model, criterion, optimizer
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    model = Livenet().to(device)  # Move model to the device
    criterion = nn.MSELoss()  # L2 Loss as primary loss
    perceptual_loss = PerceptualLoss().to(device)  # Initialize perceptual loss
    optimizer = optim.Adam(model.parameters(), lr=1e-4)

    # Mixed precision training scaler
    scaler = GradScaler()

    # Add checkpoint saving frequency
    CHECKPOINT_INTERVAL = 20

    # Main training logic
    num_epochs = 200
    for epoch in range(num_epochs):
        print(f"Epoch {epoch+1}/{num_epochs}")
        
        # Clear GPU memory
        torch.cuda.empty_cache()

        # Train model
        train_loss = train_model(model, train_loader, criterion, optimizer, device, perceptual_loss, scaler)
        print(f"Training Loss: {train_loss:.4f}")

        # Save checkpoint every CHECKPOINT_INTERVAL epochs
        if (epoch + 1) % CHECKPOINT_INTERVAL == 0:
            save_checkpoint(model, optimizer, epoch + 1, CHECKPOINT_PATH)


if __name__ == '__main__':
    main()
